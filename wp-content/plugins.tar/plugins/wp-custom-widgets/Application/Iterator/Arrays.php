<?php

namespace Application\Iterator;

use ArrayIterator;

class Arrays {

	public static function getArray() {

	}
}