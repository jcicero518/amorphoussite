# WP REST API V2 Menus
Adding menus endpoints on WP REST API v2

## Routes
Get all menus:

    GET /menus/v1/menus
    
Get menus data from slug:

    GET /menus/v1/menus/{slug}
