# oembed-gist

[![Build Status](https://travis-ci.org/miya0001/oembed-gist.svg)](https://travis-ci.org/miya0001/oembed-gist)
[![](https://img.shields.io/wordpress/plugin/dt/oembed-gist.svg)](https://wordpress.org/plugins/oembed-gist/)
[![](https://img.shields.io/wordpress/v/oembed-gist.svg)](https://wordpress.org/plugins/oembed-gist/)
[![](https://img.shields.io/wordpress/plugin/r/oembed-gist.svg)](https://wordpress.org/plugins/oembed-gist/)

* https://wordpress.org/plugins/oembed-gist/

## Contributing

```
$ git clone https://github.com/miya0001/oembed-gist
$ cd oembed-gist
$ bash bin/install-wp-tests.sh wordpress_test root '' localhost $WP_VERSION
$ phpunit
```
