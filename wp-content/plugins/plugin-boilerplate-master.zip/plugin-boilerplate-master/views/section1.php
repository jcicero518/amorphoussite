<?php
/**
 * Admin page section view
 *
 * @package      Gamajo\PluginSlug
 * @author       Gary Jones
 * @copyright    2017 Gamajo
 * @license      GPL-2.0+
 */

?>
<p>This is the section 1 view.</p>
