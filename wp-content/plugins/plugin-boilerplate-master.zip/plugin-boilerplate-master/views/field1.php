<?php
/**
 * Admin page section field view
 *
 * @package      Gamajo\PluginSlug
 * @author       Gary Jones
 * @copyright    2017 Gamajo
 * @license      GPL-2.0+
 */

?>
<p>This is the field 1 view.</p>
